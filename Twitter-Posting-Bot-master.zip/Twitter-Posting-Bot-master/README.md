#Twitter Bot that will Post for You!

1. To get started just download this application and change the values in the config.js file to your own configuration values that can be obtained at https://apps.twitter.com by creating a new app.
2. You will want to change to messages your bot will post, so go to bot.js and change the values in the messages variable to the messages you want you bot to post.
3. Finally you are going to want to set a time interval for your bot to post, so go the the last function on bot.js called setInterval, and change the number to your desired value. (Hint: multiply the time desired in minutes by 30,000)
