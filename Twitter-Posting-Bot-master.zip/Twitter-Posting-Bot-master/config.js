var twit = require('twit');
var config = require('./config.js');

module.exports = {
    consumer_key: 'xC1R5DhvItuBXRvqgXltFShp7',
    consumer_secret: '5B21i28wxUHVd9npptanICy1Kay7S4578t2V3imm7BnV2PkjbZ',
    access_token: '1670589211-n8kjCx4w0b5W2a3COSOBL3Qb8Epg6G3fhiDMGGj',
    access_token_secret: '9RFuKDhh2d4GVcVaSXDApFRgntUGJSxP5v7LpC3FmaIhO'
}
